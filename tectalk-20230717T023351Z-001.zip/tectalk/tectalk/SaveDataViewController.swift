//
//  SaveDataViewController.swift
//  tectalk
//
//  Created by min on 2021/10/22.
//

import Foundation
import UIKit


class SaveDataViewController: UIViewController {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var saveDataView: UIView!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var okButton: UIButton!
    
    var number1 : String?
    var nuber2: String?
    
    override func viewDidLoad() {
        saveDataView.layer.cornerRadius = 15.0
        
    }
    
    
    @IBAction func savedata(_ sender: Any) {

        
        self.dismiss(animated: true)
        
        
    }
    
    @IBAction func canelData(_ sender: Any) {
        
        self.dismiss(animated: true)
    }
}
