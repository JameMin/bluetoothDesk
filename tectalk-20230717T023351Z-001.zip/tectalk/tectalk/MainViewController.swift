//
//  ViewController.swift
//  tectalk
//
//
//

import Foundation
import CoreBluetooth
import UIKit

class MainViewController: UIViewController,UIScrollViewDelegate, UITableViewDelegate,UITableViewDataSource {
    //MARK: - ble필요 변수 선언
    
    var manager = CBCentralManager()
    var PeripheralManager: CBPeripheral!
    var peripherals: [CBPeripheral] = []
    private(set) var connectedServices:[CBService]?
    var systemBluetoothConnectedState = false
    var connectedPeripheral:CBPeripheral?
    var nearbyPeripherals : [(CBPeripheral,String)] = []
    var delegate :BLEDelegate?
    var seletedIndex : IndexPath?
    var mode = 0
    
    /// OBD 특성 저장 변수
    var char : CBCharacteristic?
 
    var writeChar : CBCharacteristic?
    var timer = Timer()
    
    @IBOutlet weak var ConnectingButton: ARoundButton!
    @IBOutlet weak var bleConnectLabel: UILabel!
    
    @IBOutlet weak var NameView: UIView!
    @IBOutlet weak var bleListTable: UITableView!
    
    @IBOutlet weak var dashBoard: UIImageView!
    
    @IBOutlet weak var reFreshButton: UIButton!
    
    var dataByteString = ""
    
    //MARK: - 책상 뷰 변수 선언
    
    @IBOutlet weak var deskTitleLabel: UILabel!
    @IBOutlet weak var mainContentBackgroundView: UIView!
    @IBOutlet weak var singleDeskView: UIView!
    
    @IBOutlet weak var newView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet var mainDataCellPointViewCollection: [UIView]!
    @IBOutlet weak var pageViewControl: UIPageControl!
  
    @IBOutlet weak var desksideLabel: UILabel!
    @IBOutlet weak var workSpaceValueLabel: UILabel!
    @IBOutlet weak var infinitySpaceValueLabel: UILabel!
    
    @IBOutlet weak var mainLeftBlueView: UIView!
    @IBOutlet weak var mainRightBlueView: UIView!
    @IBOutlet weak var singledeskindiView: UIView!
    
    @IBOutlet weak var workSpaceUpBtn: UIButton!
    @IBOutlet weak var workSpaceDownBtn: UIButton!
    @IBOutlet weak var infinitySpaceUpBtn: UIButton!
    @IBOutlet weak var infinitySpaceDownBtn: UIButton!
    @IBOutlet weak var deskBottomImageView: UIImageView!
    @IBOutlet weak var deskMiddle1ImageView: UIImageView!
    @IBOutlet weak var deskMiddle2ImageView: UIImageView!
    @IBOutlet weak var deskTop1ImageView: UIImageView!
    @IBOutlet weak var deskTop2ImageView: UIImageView!
    
    @IBOutlet weak var unconnectTop1: UIImageView!
    @IBOutlet weak var unconnectTop2: UIImageView!
    @IBOutlet weak var unconnectmid1: UIImageView!
    @IBOutlet weak var unconnectmid2: UIImageView!
    @IBOutlet weak var unconnectdesktitle: UILabel!
    @IBOutlet weak var unconnectedbottom: UIImageView!
    
    @IBOutlet weak var closeViewButton: UIButton!
    
    @IBOutlet weak var closebleViewButton: UIButton!
    @IBOutlet weak var singleinfinitySpaceValueLabel: UILabel!
    @IBOutlet weak var singledeskupperTopImageView: UIImageView!
    @IBOutlet weak var singledeskBottomImageView: UIImageView!
    @IBOutlet weak var singledeskMiddleImageView: UIImageView!
    
    @IBOutlet weak var singleconnectLabel: UILabel!
    @IBOutlet weak var singleinacttop: UIImageView!
    @IBOutlet weak var singleinactmid: UIImageView!
    @IBOutlet weak var singleinactbottom: UIImageView!
    @IBOutlet weak var singleDeskSide: UILabel!
    
    @IBOutlet weak var singleinfinitySpaceUpBtn: UIButton!
    @IBOutlet weak var singleinfintySpaceDownBtn: UIButton!
    
    @IBOutlet weak var saveDeskData1View: UIView!
    @IBOutlet weak var saveDeskData2View: UIView!
    @IBOutlet weak var saveDeskData3View: UIView!
    @IBOutlet weak var saveDeskData4View: UIView!
    
    //MARK: - 책상 계산
    
    var isOn = false
    var zeroTop1MinY : CGFloat = 0.0
    var zeroTop2MinY : CGFloat = 0.0
    var maxTop1MinY : CGFloat = 0.0
    var maxTop2MinY : CGFloat = 0.0
    var zeroMiddleMinY : CGFloat = 0.0
    var maxMiddleMinY : CGFloat = 0.0
    
    private var zeroTop1MinYs : CGFloat = 0.0
    private var zeroTop2MinYs : CGFloat = 0.0
    private var maxTop1MinYs : CGFloat = 0.0
    private var maxTop2MinYs : CGFloat = 0.0
    private var zeroMiddleMinYs : CGFloat = 0.0
    private var maxMiddleMinYs : CGFloat = 0.0
    var datavalue : String?
    
    var testTimer : Timer?
    
    private   let SPACE_MIN = 63.0
    private let SPACE_MAX = 127.0
    
    var currdeskheights : Double = 0.0
    var infideskheight : Double = 0.0
    
    private  let SPACE_MINs = 63.0
    private   let SPACE_MAXs = 127.0
    
    var currnet_workSpace = 63.0
    var currnet_infinitySpace = 63.0
    
    var preResultValue1 : Double = 0.0
    var preResultValue2 : Double = 0.0
    
    var delayCheck = false
    var preValue1 = 0.0
    var preValue2 = 0.0
    
    var preValue4 = 0.0
    var delayChecks = false
    
    var images = [#imageLiteral(resourceName: "test3"), #imageLiteral(resourceName: "test1")]
    var imageViews = [UIImageView]()
    
    
    // MARK: - view표시
    override func viewDidLoad() {
        super.viewDidLoad()
        initView()
        initViews()
        closeViewButton.titleLabel!.text = ""
        closebleViewButton.titleLabel!.text = ""
        bleListTable.dataSource = self
        bleListTable.delegate = self
        
        manager = CBCentralManager(delegate: self, queue: nil)
        bleListTable.tableFooterView = UIView()  //빈공간 밑줄 제거
        bleListTable.bounces = false
        NameView.layer.cornerRadius = 25
        
        bleListTable.allowsMultipleSelection = true
      
        reFreshButton.setTitle("", for: .normal)
        
        addContentScrollView()
        scrollView.delegate = self
        scrollView.isPagingEnabled = true
        
        setPageControl()
    
        if #available(iOS 14.0, *) {
            self.pageViewControl.backgroundStyle = .automatic
            self.pageViewControl.allowsContinuousInteraction = false
            let myImage = UIImage(named: "selecting")
            pageViewControl.setIndicatorImage(myImage, forPage: 0)
            let myImages = UIImage(named: "circle")
            pageViewControl.setIndicatorImage(myImages, forPage: 1)

            
        } else {
            // Fallback on earlier versions
        }
  
        UserDefaults.standard.synchronize()
    }

    func initView(){
        
        mainLeftBlueView.roundCorners(cornerRadius: 5, maskedCorners: [ .layerMaxXMaxYCorner,.layerMaxXMinYCorner])
        mainRightBlueView.roundCorners(cornerRadius: 5, maskedCorners: [.layerMaxXMaxYCorner,.layerMaxXMinYCorner])
        singledeskindiView.roundCorners(cornerRadius: 5, maskedCorners: [.layerMaxXMaxYCorner,.layerMaxXMinYCorner])
        
        scrollView.roundCorners(cornerRadius: 10, maskedCorners: [.layerMinXMaxYCorner, .layerMaxXMaxYCorner, .layerMinXMinYCorner, .layerMaxXMinYCorner])
        
        mainContentBackgroundView.roundCorners(cornerRadius: 10, maskedCorners: [.layerMinXMaxYCorner, .layerMaxXMaxYCorner, .layerMinXMinYCorner, .layerMaxXMinYCorner])
        singleDeskView.roundCorners(cornerRadius: 10, maskedCorners: [.layerMinXMaxYCorner, .layerMaxXMaxYCorner, .layerMinXMinYCorner, .layerMaxXMinYCorner])
        //
        singleinfinitySpaceUpBtn.roundCorners(cornerRadius: 16, maskedCorners: [.layerMinXMinYCorner, .layerMaxXMinYCorner])
        singleinfintySpaceDownBtn.roundCorners(cornerRadius: 16, maskedCorners: [.layerMinXMaxYCorner, .layerMaxXMaxYCorner])
        
        closeViewButton.setTitle("", for: .normal)
        singleinfinitySpaceUpBtn.setTitle("", for: .normal)
        singleinfintySpaceDownBtn.setTitle("", for: .normal)
        
        
        singleinfinitySpaceUpBtn.setImage(UIImage(named: "up"), for: .normal)
        singleinfintySpaceDownBtn.setImage(UIImage(named: "down"), for: .normal)
        
        mainDataCellPointViewCollection.forEach { item in
            item.roundCorners(cornerRadius: 5, maskedCorners: [.layerMaxXMinYCorner, .layerMaxXMaxYCorner])
        }
        
        workSpaceUpBtn.roundCorners(cornerRadius: 16, maskedCorners: [.layerMinXMinYCorner, .layerMaxXMinYCorner])
        workSpaceDownBtn.roundCorners(cornerRadius: 16, maskedCorners: [.layerMinXMaxYCorner, .layerMaxXMaxYCorner])
        
        infinitySpaceUpBtn.roundCorners(cornerRadius: 16, maskedCorners: [.layerMinXMinYCorner, .layerMaxXMinYCorner])
        infinitySpaceDownBtn.roundCorners(cornerRadius: 16, maskedCorners: [.layerMinXMaxYCorner, .layerMaxXMaxYCorner])
        workSpaceUpBtn.setTitle("", for: .normal)
        workSpaceDownBtn.setTitle("", for: .normal)
        infinitySpaceUpBtn.setTitle("", for: .normal)
        infinitySpaceDownBtn.setTitle("", for: .normal)
        
        workSpaceUpBtn.setImage(UIImage(named: "up"), for: .normal)
        workSpaceDownBtn.setImage(UIImage(named: "down"), for: .normal)
        infinitySpaceUpBtn.setImage(UIImage(named: "up"), for: .normal)
        infinitySpaceDownBtn.setImage(UIImage(named: "down"), for: .normal)

        let value = Double(floor(currnet_workSpace))
        let values = Double(floor(currnet_infinitySpace))
        
        let change = String(format: "%.1f", value)
        let changes =  String(format: "%.1f", values)
        
        let value1 = change + "cm"
        let value2 = changes + "cm"
        
        self.workSpaceValueLabel.text = value1
        
        self.infinitySpaceValueLabel.text = value2
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        setDeskPostion()
        setDeskPostions()
        
    }
 
    private func setPageControl() {
        
        pageViewControl.numberOfPages = 2
        
    }
 
    private func setPageControlSelectedPage(currentPage:Int) {
        pageViewControl.currentPage = currentPage
    }
    // MARK: - 페이징 구현
  
    private func addContentScrollView() {
        
        for i in 0..<images.count {
            let imageView = UIImageView()
            let xPos = self.view.frame.width * CGFloat(i)
            imageView.frame = CGRect(x: xPos, y: 0, width: scrollView.bounds.width, height: scrollView.bounds.height)
            imageView.image = images[i]
            //               scrollView.addSubview(imageView)
            scrollView.contentSize.width = imageView.frame.width * CGFloat(i + 1)
            Swift.print("스크롤뷰크기\(scrollView.frame)")
        }
        
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        
        
        let value = scrollView.contentOffset.x/scrollView.frame.size.width
        setPageControlSelectedPage(currentPage: Int(round(value)))
        
        
        if pageViewControl.currentPage == 0 {
            let myImage = UIImage(named: "selecting")
            if #available(iOS 14.0, *) {
                pageViewControl.setIndicatorImage(myImage, forPage: 0)
                let newImage = UIImage(named: "cicrle")
                pageViewControl.setIndicatorImage(newImage, forPage: 1)
            }
            deskTitleLabel.text = "더블 모션 데스크"
            
        }
        
        else {
            deskTitleLabel.text = "싱글 모션 데스크"
            let myImage = UIImage(named: "selecting")
            if #available(iOS 14.0, *) {
                pageViewControl.setIndicatorImage(myImage, forPage: 1)
                let newImage = UIImage(named: "cicrle")
                pageViewControl.setIndicatorImage(newImage, forPage: 0)
            } else {
                // Fallback on earlier versions
            }
            
        }
    }

    // MARK: - 데이터 저장 함수
    
    @IBAction func saveDeskdata1(_ sender: Any) {
        
        if saveDeskData4View.backgroundColor == .colorFromHex(11254491) {
            
            Swift.print("하고 있으심?")
            print(UserDefaults.standard)
            let plist = UserDefaults.standard
            plist.set(preValue1, forKey: "high")
            plist.set(preValue2, forKey: "high2")
  
            if deskTitleLabel.text == "싱글 모션 데스크"   {
  
                singlesavedatas()
                
                singlesavefirst()
                
            }
            
            savefirst()
            
            saveDeskData4View.backgroundColor = .colorFromHex(14737632)
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000), execute: { [self] in
                
                saveDeskData1View.backgroundColor = .colorFromHex(14737632)
            })
            
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000), execute: { [self] in
            
            saveDeskData1View.backgroundColor = .colorFromHex(14737632)
        })
        
        
        saveDeskData1View.backgroundColor = .colorFromHex(11254491)
        saveDeskData2View.backgroundColor = .colorFromHex(14737632)
        saveDeskData3View.backgroundColor = .colorFromHex(14737632)
        saveDeskData4View.backgroundColor = .colorFromHex(14737632)
        savefirst()
        
        let plist = UserDefaults.standard
        
        if deskTitleLabel.text == "싱글 모션 데스크"  {
            
            singleinfinitySpaceValueLabel.text = plist.string(forKey: "singledata1") ?? "63.0cm"
            
            singlesavefirst()
            
        }
        
        workSpaceValueLabel.text =   plist.string(forKey: "data1") ?? "63.0cm"
        infinitySpaceValueLabel.text = plist.string(forKey: "data2") ?? "63.0cm"
        
        
    }
    
    @IBAction func saveDesktdata2(_ sender: Any) {
        
        
        if saveDeskData4View.backgroundColor == .colorFromHex(11254491) {
            
            
            let plist = UserDefaults.standard
            
            Swift.print("하고 있으심?")
            print(UserDefaults.standard)
            plist.set(preValue1, forKey: "high3")
            plist.set(preValue2, forKey: "high4")
            
            
            if deskTitleLabel.text == "싱글 모션 데스크"   {
                //   plist.set(savetest3, forKey: "singledata2")
                
                
                singlesavedatas()
                singlesavesecond()
                
            }
            
            UserDefaults.standard.synchronize()
            
            savesecond()
            
            
            saveDeskData4View.backgroundColor = .colorFromHex(14737632)
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000), execute: { [self] in
                
                saveDeskData2View.backgroundColor = .colorFromHex(14737632)
            })
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000), execute: { [self] in
            
            saveDeskData2View.backgroundColor = .colorFromHex(14737632)
        })
        
        
        
        saveDeskData1View.backgroundColor = .colorFromHex(14737632)
        saveDeskData2View.backgroundColor = .colorFromHex(11254491)
        saveDeskData3View.backgroundColor = .colorFromHex(14737632)
        saveDeskData4View.backgroundColor = .colorFromHex(14737632)
        savesecond()
        
        let plist = UserDefaults.standard
        
        
        
        if deskTitleLabel.text == "싱글 모션 데스크"  {
            
            singleinfinitySpaceValueLabel.text = plist.string(forKey: "singledata2") ?? "63.0cm"
            savesecond()
            
        }
        
        
        workSpaceValueLabel.text =   UserDefaults.standard.string(forKey: "test2s") ?? "63.0cm"
        infinitySpaceValueLabel.text = UserDefaults.standard.string(forKey: "test2ss") ?? "63.0cm"
        
    }
    
    @IBAction func saveDeskdata3(_ sender: Any) {
        
        if saveDeskData4View.backgroundColor == .colorFromHex(11254491) {
            
            let plist = UserDefaults.standard
            
            
            print(UserDefaults.standard)
            plist.set(preValue1, forKey: "high5")
            plist.set(preValue2, forKey: "high6")
            
            
            
            if deskTitleLabel.text == "싱글 모션 데스크"   {
                
                singlesavethird()
                
                
            }
            
            plist.synchronize()
            
            
            
            savethird()
            
            saveDeskData4View.backgroundColor = .colorFromHex(14737632)
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000), execute: { [self] in
                
                saveDeskData3View.backgroundColor = .colorFromHex(14737632)
            })
            
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000), execute: { [self] in
            
            saveDeskData3View.backgroundColor = .colorFromHex(14737632)
        })
        
        
        saveDeskData1View.backgroundColor = .colorFromHex(14737632)
        saveDeskData2View.backgroundColor = .colorFromHex(14737632)
        saveDeskData3View.backgroundColor = .colorFromHex(11254491)
        saveDeskData4View.backgroundColor = .colorFromHex(14737632)
        savethird()
        
        let plist = UserDefaults.standard
        
        if deskTitleLabel.text == "싱글 모션 데스크"  {
            
            singleinfinitySpaceValueLabel.text = plist.string(forKey: "singledata3") ?? "63.0cm"
            singlesavethird()
            
        }
        
        
        workSpaceValueLabel.text =   UserDefaults.standard.string(forKey: "test3") ?? "63.0cm"
        infinitySpaceValueLabel.text = UserDefaults.standard.string(forKey: "test3s") ?? "63.0cm"
        
        
    }
    
    @IBAction func manualDeskdata(_ sender: Any) {
        
        saveDeskData1View.backgroundColor = .colorFromHex(14737632)
        saveDeskData2View.backgroundColor = .colorFromHex(14737632)
        saveDeskData3View.backgroundColor = .colorFromHex(14737632)
        saveDeskData4View.backgroundColor = .colorFromHex(11254491)
        savedatas()
        
        
    }
    
    // MARK: - 책상 위치 값 및 늘어나기
    
    
    func setDeskPostion() {
        zeroTop1MinY = deskTop1ImageView.frame.minY
        zeroTop2MinY = deskTop2ImageView.frame.minY
        
        maxTop1MinY = deskTop1ImageView.frame.minY - (deskTop1ImageView.layer.frame.height * 1.2 )
        maxTop2MinY = deskTop2ImageView.frame.minY - (deskTop2ImageView.layer.frame.height * 1.2 )
        
        zeroMiddleMinY = deskMiddle1ImageView.frame.minY
        //        maxMiddleMinY = deskMiddle1ImageView.frame.minY - (deskMiddle1ImageView.layer.frame.height * 0.45)
        maxMiddleMinY = deskMiddle1ImageView.frame.minY - (deskMiddle1ImageView.layer.frame.height * 0.6 )
        
    }
    
    func setDeskPostions() {
        zeroTop1MinYs = singledeskupperTopImageView.frame.minY
        
        maxTop1MinYs = singledeskupperTopImageView.frame.minY - (singledeskupperTopImageView.layer.frame.height * 1.2 )
        
        
        zeroMiddleMinYs = singledeskMiddleImageView.frame.minY
        //        maxMiddleMinY = deskMiddle1ImageView.frame.minY - (deskMiddle1ImageView.layer.frame.height * 0.45)
        maxMiddleMinYs = singledeskMiddleImageView.frame.minY - (singledeskMiddleImageView.layer.frame.height * 0.6 )
    }
   
    func moveDeskPostion(v1 : Double, v2 : Double) {
        
        if preValue1 == 0 , preValue2 == 0 {
            preValue1 = v1
            preValue2 = v2
            return
        }else {
            if (preValue1 - v1).magnitude > 1 || (preValue2 - v2).magnitude > 1 {
                preValue1 = v1
                preValue2 = v2
                return
            }
            preValue1 = v1
            preValue2 = v2
        }
        let pos = getDeskPostion(v1: v1, v2: v2)
        if !delayCheck {
            delayCheck = true
            UIView.animate(withDuration: 0.3, delay: 0, options: []) {
                self.deskTop1ImageView.frame = CGRect(x: self.deskTop1ImageView.frame.minX, y: pos.0, width: self.deskTop1ImageView.frame.width, height: self.deskTop1ImageView.frame.height)
                self.deskTop2ImageView.frame = CGRect(x: self.deskTop2ImageView.frame.minX, y: pos.1, width: self.deskTop2ImageView.frame.width, height: self.deskTop2ImageView.frame.height)
                self.deskMiddle1ImageView.frame = CGRect(x: self.deskMiddle1ImageView.frame.minX, y: pos.2, width: self.deskMiddle1ImageView.frame.width, height: self.deskMiddle1ImageView.frame.height)
                self.deskMiddle2ImageView.frame = CGRect(x: self.deskMiddle2ImageView.frame.minX, y: pos.3, width: self.deskMiddle2ImageView.frame.width, height: self.deskMiddle2ImageView.frame.height)
                
                self.unconnectTop1.frame = CGRect(x: self.unconnectTop1.frame.minX, y: pos.0, width: self.unconnectTop1.frame.width, height: self.unconnectTop1.frame.height)
                self.unconnectTop2.frame = CGRect(x: self.unconnectTop2.frame.minX, y: pos.1, width: self.unconnectTop2.frame.width, height: self.unconnectTop2.frame.height)
                self.unconnectmid1.frame = CGRect(x: self.unconnectmid1.frame.minX, y: pos.2, width: self.unconnectmid1.frame.width, height: self.unconnectmid1.frame.height)
                self.unconnectmid2.frame = CGRect(x: self.unconnectmid2.frame.minX, y: pos.3, width: self.unconnectmid2.frame.width, height: self.unconnectmid2.frame.height)
                
            } completion: { resut in
                self.delayCheck = false
            }
        }
        
        
    }
   
    func moveDeskPostions(v4 : Double) {
    
        if  preValue4 == 0 {
            
            preValue4 = v4
            return
        }else {
            if  (preValue4 - v4).magnitude > 1 {
                
                preValue4 = v4
                return
            }
            
            preValue4 = v4
        }
        let pos = getDeskPostions(v4: v4)
        if !delayChecks {
            delayChecks = true
            UIView.animate(withDuration: 0.03, delay: 0, options: []) {
                self.singledeskupperTopImageView.frame = CGRect(x: self.singledeskupperTopImageView.frame.minX, y: pos.0, width: self.singledeskupperTopImageView.frame.width, height: self.singledeskupperTopImageView.frame.height)
                //
                
                self.singledeskMiddleImageView.frame = CGRect(x: self.singledeskMiddleImageView.frame.minX, y: pos.1, width: self.singledeskMiddleImageView.frame.width, height: self.singledeskMiddleImageView.frame.height)
                
                self.singleinacttop.frame = CGRect(x: self.singleinacttop.frame.minX, y: pos.0, width: self.singleinacttop.frame.width, height: self.unconnectTop1.frame.height)
                self.singleinactmid.frame = CGRect(x: self.singleinactmid.frame.minX, y: pos.1, width: self.singleinactmid.frame.width, height: self.singleinactmid.frame.height)
                
            } completion: { resut in
                self.delayChecks = false
            }
        }
        
    }
    
    
    func getDeskPostion(v1 : Double, v2 : Double) -> (Double,Double,Double,Double){
        var persent1 = v1
        var persent2 = v2
        
        if persent1 > 1 {
            persent1 = 1
        }else if persent1 < 0 {
            persent1 = 0
        }
        if persent2 > 1 {
            persent2 = 1
        }else if persent2 < 0 {
            persent2 = 0
        }
        let ty1 = zeroTop1MinY - ((zeroTop1MinY - maxTop1MinY) * persent1)
        let ty2 = zeroTop2MinY - ((zeroTop2MinY - maxTop2MinY) * persent2)
        
        let my1 = zeroMiddleMinY - ((zeroMiddleMinY - maxMiddleMinY) * persent1)
        let my2 = zeroMiddleMinY - ((zeroMiddleMinY - maxMiddleMinY) * persent2)
        
        
        return (ty1,ty2,my1,my2)
    }
    
    
    func getDeskPostions(v4 : Double) -> (Double,Double){
        
        var persent4 = v4
        
        
        if persent4 > 1 {
            persent4 = 1
        }else if persent4 < 0 {
            persent4 = 0
        }
        
        let ty2s = zeroTop1MinYs - ((zeroTop1MinYs - maxTop1MinYs) * persent4)
        
        let my2s = zeroMiddleMinYs - ((zeroMiddleMinYs - maxMiddleMinYs) * persent4)
        
        
        return (ty2s,my2s)
    }
    
    
    
    // MARK: - ble 연결하기
    
    
    func connectPeripheral(_ peripheral: CBPeripheral){
        closeViewButton.titleLabel!.text = ""
        closebleViewButton.titleLabel!.text = ""
        
        manager.connect(peripheral, options: nil)
        
        
        
    }
    
    func readValueForCharacteristic(characteristic: CBCharacteristic){
        if connectedPeripheral == nil {
            return
        }
        connectedPeripheral?.readValue(for: characteristic)
        
    }
    
    func writeValue(data: Data, forCharacteristic characteristic: CBCharacteristic, type: CBCharacteristicWriteType, mode : Int){
        if connectedPeripheral == nil {
            return
        }
        self.mode = mode
        let character = writeChar != nil ? writeChar! : characteristic
        connectedPeripheral?.writeValue(data, for: character, type:type)
    }
    
    
    @IBAction func bleconnectView(_ sender: UIButton) {
        closeViewButton.titleLabel!.text = ""
        closebleViewButton.titleLabel!.text = ""
        newView.isHidden = false
        
    }
    
    func disconnectPeripheral(){
        
        if connectedPeripheral != nil {
            manager.cancelPeripheralConnection(connectedPeripheral!)
            //            startScanPeripheral()
            connectedPeripheral = nil
            
            unconnectTop1.isHidden = false
            unconnectTop2.isHidden = false
            unconnectmid1.isHidden = false
            unconnectmid2.isHidden = false
            unconnectedbottom.isHidden = false
            unconnectdesktitle.isHidden = false
            
            singleinacttop.isHidden = false
            singleinactmid.isHidden = false
            singleinactbottom.isHidden = false
            singleDeskSide.isHidden = false
            
            bleListTable.allowsMultipleSelection = true
            
            
        }
    }
    
    
    func reloadData () {
        if systemBluetoothConnectedState {
            nearbyPeripherals.removeAll()
            if let connectedPeripheral = connectedPeripheral {
                let mac = connectedPeripheral.identifier.uuidString
                nearbyPeripherals.append((connectedPeripheral,mac))
            }
            startScanPeripheral()
            self.bleListTable.reloadData()
        }
        else {
            startScanPeripheral()
            nearbyPeripherals.removeAll()
            self.bleListTable.reloadData()
        }
    }
    
    @IBAction func reScanbutton(_ sender: Any) {
        
        reloadData()
        
    }
    
    
    func startScanPeripheral(){
        manager.scanForPeripherals(withServices: nil)
    }
    
    
    func discoverCharacteristics(){
        if connectedPeripheral == nil {
            return
        }
        
        let services = connectedPeripheral?.services
        if services == nil || (services?.count)! < 1 {
            return
        }
        connectedServices = []
        for service in services! {
            print("service : \(service)")
            connectedServices?.append(service)
        }
    }
    
    
    func discoverDescriptor(_ characteristic: CBCharacteristic){
        if connectedPeripheral != nil {
            connectedPeripheral?.discoverDescriptors(for: characteristic)
        }
    }
    
    
    func connectError() {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainVC = storyboard.instantiateViewController(withIdentifier: "FailConnectViewController") as! FailConnectViewController
        
        mainVC.modalPresentationStyle = .popover//전체화면(기본은 팝업형태)
        self.present(mainVC, animated: true, completion: nil)
        
    }
    
    func stopScanPeripheral(){
        manager.stopScan()
    }
    
    // MARK: - 블루투스 목록 닫기
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){

         self.newView.endEditing(true)

   }


    @IBAction func closebleView(_ sender: Any) {
        closebleViewButton.setTitle("", for: .normal)
        closeViewButton.setTitle("", for: .normal)
        
        newView.isHidden = true
    }

    
    @IBAction func closeView(_ sender: Any) {
        closebleViewButton.titleLabel!.text = ""
        closeViewButton.titleLabel!.text = ""
        
        newView.isHidden = true
        
        
    }
    // MARK: - 책상 움직이는 버튼 동작
    
    func showToast(message : String) {
      
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/5, y: self.view.frame.size.height-100, width: 250, height: 35))
          // 뷰가 위치할 위치를 지정해준다. 여기서는 아래로부터 100만큼 떨어져있고, 너비는 양쪽에 10만큼 여백을 가지며, 높이는 35로
          toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
          toastLabel.textColor = UIColor.white
          toastLabel.textAlignment = .center;
          toastLabel.font = UIFont(name: "Montserrat-Light", size: 12.0)
          toastLabel.text = message
          toastLabel.backgroundColor = .colorFromHex(11254491)
          toastLabel.alpha = 1.0
          toastLabel.layer.cornerRadius = 10;
          toastLabel.clipsToBounds  =  true
          self.view.addSubview(toastLabel)
          UIView.animate(withDuration: 3.0, delay: 1, options: .curveEaseOut, animations: {
              toastLabel.alpha = 0.0
          }, completion: {(isCompleted) in
              toastLabel.removeFromSuperview()
          })
      }

    @IBAction func infinityup(_ sender: Any) {
        Swift.print("후후")
        timer.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(infinitydeskup), userInfo: nil, repeats: true)
        self.showToast(message: "모니터가 이동중입니다.")
    }
    
    
    @IBAction func infinitydown(_ sender: Any) {
        Swift.print("하하")
        timer.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(infinitydeskdown), userInfo: nil, repeats: true)
        self.showToast(message: "모니터가 이동중입니다.")
        
    }
    
    @IBAction func infintydeskstop(_ sender: UIButton) {
        
        
        timer.invalidate()
        
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(movestop), userInfo: nil, repeats: false)
        self.showToast(message: "모니터 이동이 끝났습니다.")
        
        
    }
    
    
    @IBAction func workdeskup(_ sender: Any) {
        
        Swift.print("책상")
        timer.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(workdeskups), userInfo: nil, repeats: true)
        self.showToast(message: "책상과 모니터가 이동중입니다.")
    }
    
    
    @IBAction func workdeskdown(_ sender: Any) {
        
        timer.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(workdeskdowns), userInfo: nil, repeats: true)
        self.showToast(message: "책상과 모니터가 이동중입니다.")
        
    }
    
    
 
    @IBAction func workdeskstop(_ sender: UIButton) {
        
        
        timer.invalidate()
        
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(movestop), userInfo: nil, repeats: false)
        self.showToast(message: "책상과 모니터 이동이 끝났습니다.")
        
        
    }
 
 
    
    func writeValue(_ data: Data){
        if connectedPeripheral == nil {
            return
        }
        
        if writeChar != nil {
            connectedPeripheral?.writeValue(data, for: writeChar!, type:.withResponse)
        }else if char != nil {
            connectedPeripheral?.writeValue(data, for: char!, type:.withResponse)
        }else {
            
            print("Char nil..")
        }
    }
    
    // MARK: - 책상 움직이는 함수
    @objc func infinitydeskup()
    {
        let data = Data([0x31,0x0D,0x0A])
        writeValue(data)
    }
    
    @objc func movestop()
    {
        let data = Data([0xff,0x0D,0x0A])
        writeValue(data)
        
    }
    
    @objc func infinitydeskdown()
    {
        let data = Data([0x32,0x0D,0x0A])
        writeValue(data)
    }
    
    @objc func workdeskups()
    {
        let data = Data([0x37,0x0D,0x0A])
        writeValue(data)
    }
    
    
    
    @objc func workdeskdowns()
    {
        let data = Data([0x38,0x0D,0x0A])
        writeValue(data)
    }
    
    @objc func savedatas()
    {
        let data = Data([0x36,0x0D,0x0A,0xff])
        
        writeValue(data)
    }
    
    @objc func savefirst()
    {
        
        let data = Data([0x33,0x0D,0x0A,0xff])
        writeValue(data)
    }
    
    @objc func savesecond()
    {
        let data = Data([0x34,0x0D,0x0A,0xff])
        writeValue(data)
    }
    
    @objc func savethird()
    {
        let data = Data([0x35,0x0D,0x0A,0xff])
        writeValue(data)
    }
    
    @objc func singlesavedatas()
    {
        let data = Data([0x36,0x0D,0x0A])
        
        writeValue(data)
    }
    
    @objc func singlesavefirst()
    {
        
        let data = Data([0xff,0x33,0x0D,0x0A])
        writeValue(data)
    }
    
    @objc func singlesavesecond()
    {
        let data = Data([0xff,0x34,0x0D,0x0A])
        writeValue(data)
    }
    
    @objc func singlesavethird()
    {
        let data = Data([0xff,0x35,0x0D,0x0A])
        writeValue(data)
    }
    
    // MARK: - TableView function
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if bleListTable == self.bleListTable {
            return nearbyPeripherals.count
        }
        else {
            return peripherals.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Connect to device where the peripheral is connected
        
        let cell = (tableView.dequeueReusableCell(withIdentifier: "BleListCell", for: indexPath) as? BleListCell)!
        let peripheral = self.nearbyPeripherals[indexPath.row]
        let peris = peripheral.0.name
        
        
        cell.bluetoothImage!.image = UIImage(named:"icn_bluetooth")
        cell.nameLabel?.text = peris
        cell.nameLabel?.textColor = .black
        
        cell.backgroundColor = .white
        cell.selectionStyle = .none
      


        return cell
    }
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if bleListTable == self.bleListTable {
            
            seletedIndex = indexPath
            
            let peripheral = self.nearbyPeripherals[indexPath.row]
     
//            if peripheral.0.name?.contains("TECTALK") == true {
//                connectPeripheral(peripheral.0)
//            }
//            else{
//                tableView.deselectRow(at: seletedIndex!, animated: true)
//                disconnectPeripheral()
//            }
            
        }
        
        
        
    }
    
    //
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
        if bleListTable == self.bleListTable {
            
            seletedIndex = indexPath
            
            let peripheral = self.nearbyPeripherals[indexPath.row]
            
            disconnectPeripheral()
            
        }
        
    }
}
