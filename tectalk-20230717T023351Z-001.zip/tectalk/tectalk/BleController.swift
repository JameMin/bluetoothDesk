////
////  BleController.swift
////  tectalk
////
////  Created by min on 2021/10/20.
////
//
//import CoreBluetooth
//import Foundation
//import UIKit
//
//
//
//class BleController: UIViewController,UITableViewDelegate,UITableViewDataSource    {
//
//    var manager = CBCentralManager()
//    var PeripheralManager: CBPeripheral!
//    var peripherals: [CBPeripheral] = []
//    private(set) var connectedServices:[CBService]?
//    var myPeripheral: CBPeripheral!
//    var systemBluetoothConnectedState = false
//    private(set) var connectedPeripheral:CBPeripheral?
//    var nearbyPeripherals : [(CBPeripheral,String)] = []
//    var delegate :BLEDelegate?
//    private var timeoutMonitor : Timer?
//    var seletedIndex : IndexPath?
//    var mode = 0
//    var requestID : String? = "ATZ"
//    var atCommands : [String] = []
//    lazy private var atCommandIterator = atCommands.makeIterator()
//
//    @IBOutlet weak var upBtn: UIButton!
//    /// OBD 특성 저장 변수
//    var char : CBCharacteristic?
//
//    @IBOutlet weak var downBtn: UIButton!
//    var writeChar : CBCharacteristic?
//    var timer = Timer()
//
//    @IBOutlet weak var BleListLabel: UILabel!
//    @IBOutlet weak var bleConnectLabel: UILabel!
//
//    @IBOutlet weak var NameView: UIView!
//    @IBOutlet weak var bleListTable: UITableView!
//
//    @IBOutlet weak var dashBoard: UIImageView!
//
//    @IBOutlet weak var reFreshButton: UIButton!
//
//    var dataByteString = ""
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        bleListTable.dataSource = self
//        bleListTable.delegate = self
////        self.bleListTable.register(BleListCell.self,forCellReuseIdentifier: "BleListCell")
//        manager = CBCentralManager(delegate: self, queue: nil)
//        bleListTable.tableFooterView = UIView()  //빈공간 밑줄 제거
//        bleListTable.bounces = false
//        NameView.layer.cornerRadius = 25
//        bleListTable.allowsMultipleSelection = true
//
//
//
//        reFreshButton.setTitle("", for: .normal)
//    }
//
//
//    func connectPeripheral(_ peripheral: CBPeripheral){
//
//        manager.connect(peripheral, options: nil)
//
//
//        }
//
//
//    //AT 커맨드 설정
//    func setATCommands(){
//        atCommands = ["ATZ", "ATE0", "ATD0", "ATSP0", "ATH1", "ATM0", "ATS0", "ATAT1", "ATST64"]
//        if atCommands.contains("NONE") {
//            atCommands = atCommands.filter{$0 != "NONE"}
//        }
//        requestID = "ATZ"
//        atCommandIterator = atCommands.makeIterator()
//    }
//    func nextATCommand() -> String? {
//        requestID = atCommandIterator.next()
//        return requestID
//    }
//
//    func atCommandNext() {
//        if let command = nextATCommand() {
//            Swift.print(command)
//             writeValue("\(command)\r".data(using: .utf8)!)
//
//                atCommandNext()
//
//
//            }
//
//        }
//
//
//    func readValueForCharacteristic(characteristic: CBCharacteristic){
//        if connectedPeripheral == nil {
//            return
//        }
//        connectedPeripheral?.readValue(for: characteristic)
//
//    }
//
//    func writeValue(data: Data, forCharacteristic characteristic: CBCharacteristic, type: CBCharacteristicWriteType, mode : Int){
//        if connectedPeripheral == nil {
//            return
//        }
//        self.mode = mode
//        let character = writeChar != nil ? writeChar! : characteristic
//        connectedPeripheral?.writeValue(data, for: character, type:type)
//    }
//
//    @IBAction func testdownfunction(_ sender: UIButton) {
//        timer.invalidate()
//        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(speeding), userInfo: nil, repeats: true)
//    }
//    @IBAction func testfunction(_ sender: UIButton) {
//        timer.invalidate()
//        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(speeds), userInfo: nil, repeats: true)
//    }
//
//    @IBAction func stopfunction(_ sender: Any) {
//
//        stop()
//    }
//    func writeValue(_ data: Data){
//        if connectedPeripheral == nil {
//            return
//        }
//
//        if writeChar != nil {
//            connectedPeripheral?.writeValue(data, for: writeChar!, type:CBCharacteristicWriteType.withResponse)
//        }else if char != nil {
//            connectedPeripheral?.writeValue(data, for: char!, type:CBCharacteristicWriteType.withResponse)
//        }else {
//            atCommandNext()
//            print("Char nil..")
//        }
//    }
//
//
//
//    func disconnectPeripheral(){
//
//        if connectedPeripheral != nil {
//            manager.cancelPeripheralConnection(connectedPeripheral!)
////            startScanPeripheral()
//            connectedPeripheral = nil
//
//
//
//        }
//    }
//
//
//    func reloadData () {
//        nearbyPeripherals.removeAll()
//        startScanPeripheral()
//        self.bleListTable.reloadData()
//
//    }
//
//    @IBAction func reScanbutton(_ sender: Any) {
//
//        reloadData()
//
//    }
//
//
//    func startScanPeripheral(){
//        manager.scanForPeripherals(withServices: nil)
//    }
//
//
//    func discoverCharacteristics(){
//        if connectedPeripheral == nil {
//            return
//        }
//
//        let services = connectedPeripheral?.services
//        if services == nil || (services?.count)! < 1 {
//            return
//        }
//        connectedServices = []
//        for service in services! {
//            print("service : \(service)")
//            connectedServices?.append(service)
//        }
//    }
//
//
//    func discoverDescriptor(_ characteristic: CBCharacteristic){
//        if connectedPeripheral != nil {
//            connectedPeripheral?.discoverDescriptors(for: characteristic)
//        }
//    }
//
//
//    func connectError() {
//
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let mainVC = storyboard.instantiateViewController(withIdentifier: "FailConnectViewController") as! FailConnectViewController
//
//        mainVC.modalPresentationStyle = .popover//전체화면(기본은 팝업형태)
//        self.present(mainVC, animated: true, completion: nil)
//
//    }
//
//    func stopScanPeripheral(){
//        manager.stopScan()
//    }
//
//    @objc func speeds()
//    {
//        writeValue("310D0A".data(using: .utf8)!)
//    }
//
//    @objc func stop()
//    {
//        writeValue("ff0D0A".data(using: .utf8)!)
//    }
//
//    @objc func speeding()
//    {
//        writeValue("320D0A".data(using: .utf8)!)
//    }
//
//
//
//
//
//    // MARK: - TableView function
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//
//        if bleListTable == self.bleListTable {
//        return nearbyPeripherals.count
//    }
//        else {
//            return peripherals.count
//        }
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        //Connect to device where the peripheral is connected
//
//        let cell = (tableView.dequeueReusableCell(withIdentifier: "BleListCell", for: indexPath) as? BleListCell)!
//        let peripheral = self.nearbyPeripherals[indexPath.row]
//        let peris = peripheral.0.name
//
//
//        cell.bluetoothImage!.image = UIImage(named:"icn_bluetooth")
//        cell.nameLabel?.text = peris
//        cell.nameLabel?.textColor = .black
//
//        cell.backgroundColor = .white
//        cell.selectionStyle = .none
//
//
////        if let connectedPeripheral = connectedPeripheral, connectedPeripheral == peripheral.0 {
////
////            cell.statusLabel.text = "연결완료"
////            cell.statusLabel.textColor = .colorFromHex(10263708)
////            cell.connectingImageView.isHidden = false
////            cell.connectingImageView.image = UIImage(named:"icn_success4")
////        }
//
//
//        Swift.print(peripheral.0.name)
//
//
//
//        return cell
//    }
//
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        if bleListTable == self.bleListTable {
//
//
//        seletedIndex = indexPath
//
//
//        let peripheral = self.nearbyPeripherals[indexPath.row]
//
//
//            connectPeripheral(peripheral.0)
//
//
//    }
//
//
//
//
//
//}
//}
//
//extension BleController: CBCentralManagerDelegate {
//
//
//    func centralManagerDidUpdateState(_ central: CBCentralManager) {
//        switch central.state {
//
//        case .unknown:
//            print("central.state is unknown")
//            systemBluetoothConnectedState = false
//            connectError()
//        case .resetting:
//            print("central.state is resetting")
//            systemBluetoothConnectedState = false
//        case .unsupported:
//            print("central.state is unsupported")
//            systemBluetoothConnectedState = false
//            connectError()
//
//        case .unauthorized:
//            print("central.state is unauthorized")
//            systemBluetoothConnectedState = false
//        case .poweredOff:
//            print("central.state is poweredOff")
//            systemBluetoothConnectedState = false
//        case .poweredOn:
//            print("central.state is poweredOn")
//            central.scanForPeripherals(withServices: nil)
//            systemBluetoothConnectedState = true
//        @unknown default:
//            print("central.state default case")
//            systemBluetoothConnectedState = false
//        }
//    }
//
//    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
//
//        if !nearbyPeripherals.contains(where: {$0.0 == peripheral}), peripheral.name != nil{
//            var macData = ""
//            if let name = peripheral.name, name.contains("infocar") {
//                if let manufacturerData = advertisementData["kCBAdvDataManufacturerData"] as? Data {
//                    if manufacturerData.count >= 6 {
//                        let mac = "\(String(format: "%02X", manufacturerData[5])):\(String(format: "%02X", manufacturerData[4])):\(String(format: "%02X", manufacturerData[3])):\(String(format: "%02X", manufacturerData[2])):\(String(format: "%02X", manufacturerData[1])):\(String(format: "%02X", manufacturerData[0]))"
//                        macData = mac
//                    }
//                }
//            }
//
//            if macData == "" {
//                macData = peripheral.identifier.uuidString
//            }
//            nearbyPeripherals.append((peripheral,macData))
//            bleListTable.reloadData()
//
//
//    }
//    }
//
//    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
//        print("connected!")
//        Swift.print("write withoutResponse length : \(peripheral.maximumWriteValueLength(for: .withoutResponse))")
//        Swift.print("write withResponse length : \(peripheral.maximumWriteValueLength(for: .withResponse))")
//
//
//        connectedPeripheral = peripheral
//        // 아래 파라미터가 nil이면 모든 서비스를 검색.
//        delegate?.didConnectedPeripheral?(peripheral)
//        stopScanPeripheral()
//        peripheral.delegate = self
//        peripheral.discoverServices(nil)
//        //  PeripheralManager.discoverServices(nil)
//        // 연결 끊기
//        //        centralManager.cancelPeripheralConnection(peripheral)
//    }
//
//    public func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
////        print("BLEManager --> didFailToConnectPeripheral")
//
////        if timeoutMonitor != nil {
////            timeoutMonitor!.invalidate()
////            timeoutMonitor = nil
////        }
////        timer.invalidate()
////        delegate?.failToConnectPeripheral?(peripheral, error: error!)
//    }
//
//    public func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
//        print("BLEManager --> didDisconnectPeripheral")
//
//        connectedPeripheral = nil
////        timer.invalidate()
//        self.delegate?.didDisconnectPeripheral?(peripheral)
//
//    }
//
//
//
//}
//
//extension BleController: CBPeripheralDelegate {
//    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
//        connectedPeripheral = peripheral
//
//        guard let services = peripheral.services else {return}
//        for service in services {
//            print("service : \(service)")
//            peripheral.discoverCharacteristics(nil, for: service)
//            Swift.print(peripheral)
//        }
//
//    }
//
//
//
//    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
//        guard let chars = service.characteristics else {
//            return
//        }
//
//        guard chars.count > 0 else {
//            return
//        }
//
//        for char in chars {
//            print("char : \(char)")
//            peripheral.setNotifyValue(true, for: char)
//            peripheral.discoverDescriptors(for: char)
//
//            if char.properties.contains(.write) {
//                writeChar = char
//            }
//
//            if char.properties.contains(.read) {
//                peripheral.readValue(for: char)
//            }
//
//        }
//
//        delegate?.didDiscoverCharacteriticsFor?(peripheral, service)
//
//    }
//
//
//    public func peripheral(_ peripheral: CBPeripheral, didDiscoverDescriptorsFor characteristic: CBCharacteristic, error: Error?) {
////        print("BLEManager --> didDiscoverDescriptorsForCharacteristic")
//        if error != nil {
////            print("BLEManager --> Fail to discover descriptor for characteristic Error:\(error?.localizedDescription ?? "error")")
//            delegate?.didFailToDiscoverDescriptors?(error!)
//            return
//        }
//        delegate?.didDiscoverDescriptors?(characteristic)
//    }
//
//
//
//
//
//
//
//    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
//        if let value = characteristic.value {
//            let bytes = [UInt8](value)
////            print("bytes : \(bytes)")
//            dataByteString.append(contentsOf: bytes.hexa.uppercased())
//            if dataByteString.contains("0D0A") {
//                print("data frame : \(dataByteString)")
//                dataByteString = ""
//            }
//        }
//
////        self.char = characteristic
//////        print("BLEManager --> didUpdateValueForCharacteristic")
////        if error != nil {
//////            print("BLEManager --> Failed to read value for the characteristic. Error:\(error!.localizedDescription)")
////            delegate?.didFailToReadValueForCharacteristic?(error!)
////            return
////        }
////
////        var responseData = ""
////
////        if let value = characteristic.value {
////
////            guard let dataString = String(data: value, encoding: .ascii) else{
////                return
////            }
////            let updateValue = dataString.replacingOccurrences(of: "\n", with: "/").replacingOccurrences(of: "\r", with: "/")
////            // ">" 로 끝나는 것을 체크 하여 다음 요청 진행
////            let nextCheck = dataString.last == ">" ? true : false
////            if nextCheck {
////                if dataString.count > 1 {
////                    responseData.append(updateValue)
////                }
////
////                responseData = ""
////            }else {
////                responseData.append(updateValue)
////
////            }
////            Swift.print(updateValue)
//////
////
////
////
////        }
////
////
////        delegate?.didReadValueForCharacteristic?(characteristic)
////        print("didUpdateValueFor characteristic")
////        print(characteristic.value ?? "can't get value")
////    }
//}
//}
//
//
//
//
////extension StringProtocol {
////    var hexa: [UInt8] {
////        var startIndex = self.startIndex
////        return (0..<count/2).compactMap { _ in
////            let endIndex = index(after: startIndex)
////            defer { startIndex = index(after: endIndex) }
////            return UInt8(self[startIndex...endIndex], radix: 16)
////        }
////    }
////}
////
////extension Sequence where Element == UInt8 {
////    var data: Data { .init(self) }
////    var hexa: String { map { .init(format: "%02x", $0) }.joined() }
////}
//
