//
//  DeskData.swift
//  tectalk
//
//  Created by min on 2021/10/26.
//

import Foundation


class DeskData : NSObject {
    
    var height: String
    var width: Int
    
    init(height oneheight: String, width onewidth: Int){
        self.height = oneheight
        self.width = onewidth
        
    }
    
    required init?(coder: NSCoder) {
        self.height = coder.decodeObject(forKey: "height") as! String
        self.width = coder.decodeInteger(forKey: "width")
        
    }
    
    func encode(with coder: NSCoder) {
        coder.encode(self.height, forKey: "height")
        coder.encode(self.width, forKey: "width")
        
        
        
    }
    
    
}


