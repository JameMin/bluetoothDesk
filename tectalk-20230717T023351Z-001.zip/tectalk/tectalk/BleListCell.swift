//
//  connectTableViewCell.swift
//  tectalk
//
//  Created by min on 2021/10/19.
//

import Foundation
import UIKit
import CoreBluetooth


class BleListCell: UITableViewCell {
    
    @IBOutlet weak var connectingImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var bluetoothImage: UIImageView!
    var nearbyPeripherals : [(CBPeripheral,String)] = []
    var manager = CBCentralManager()
    var connectedPeripheral:CBPeripheral?
    
    
    func initView() {
        self.clipsToBounds = true
        statusLabel.text = ""
        connectingImageView.isHidden = true
        
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.initView()
        
        // Initialization code
    }
    
    func connectPeripheral(_ peripheral: CBPeripheral){
        
        
        manager.connect(peripheral, options: nil)
        
        
        
    }
    
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        
        if selected {
            
            
            bluetoothImage!.image = UIImage(named:"icn_bluetooth")
            statusLabel.isHidden = false
            statusLabel.text = "연결중"
            statusLabel.textColor = .colorFromHex(10263708)
            connectingImageView.isHidden = false
            connectingImageView.image = UIImage(named:"icn_connecting")
            
            
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000), execute: { [self] in
                
             
                if nameLabel.text?.contains("TECTALK")  == true {
                    bluetoothImage.image = UIImage(named:"icn_desk")
                    statusLabel.text = "연결완료"
                    statusLabel.isHidden = false
                    nameLabel.textColor = .colorFromHex(11254491)
                    connectingImageView.isHidden = false
                    connectingImageView.image = UIImage(named:"icn_success4")
                    
                    statusLabel.textColor = .colorFromHex(10263708)
                }
                
                else {
                    
                    bluetoothImage!.image = UIImage(named:"icn_bluetooth")
                    
                    nameLabel.textColor = .black
                    statusLabel.isHidden = true
                    
                    connectingImageView.isHidden = true
                    
                    
                }
             
                
                
            } )
        }
        
        
        else {
            
            bluetoothImage!.image = UIImage(named:"icn_bluetooth")
            
            nameLabel.textColor = .black
            statusLabel.isHidden = true
            
            connectingImageView.isHidden = true
            
            
        }
        
        
        // Configure the view for the selected state
    }
    
    
    
}
