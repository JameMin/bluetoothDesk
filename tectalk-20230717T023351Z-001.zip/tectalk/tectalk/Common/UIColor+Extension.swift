//
//  UIColor+Extension.swift
//  tectalk
//
//  Created by 임국빈 on 2021/10/06.
//

import UIKit

extension UIColor {
    open class func colorFromHex(_ hex: Int) -> UIColor {
        return UIColor(red: CGFloat((hex & 0xFF0000) >> 16) / 255,
                       green: CGFloat((hex & 0x00FF00) >> 8) / 255,
                       blue: CGFloat(hex & 0x0000FF) / 255,
                       alpha: 1)
    }
    
    convenience init(colorWithHexValue value : Int, alpha: CGFloat = 1.0){
        self.init(
            red: CGFloat((value & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((value & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(value & 0x0000FF) / 255.0,
            alpha: alpha
        )
    }
}

