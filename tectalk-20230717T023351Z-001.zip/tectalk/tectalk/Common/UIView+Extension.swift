//
//  UIView+Extension.swift
//  tectalk
//
//  Created by 임국빈 on 2021/10/06.
//

import UIKit
extension UIView {
    func roundCorners(cornerRadius: CGFloat, maskedCorners: CACornerMask) {
        clipsToBounds = true
        layer.cornerRadius = cornerRadius
        layer.maskedCorners = CACornerMask(arrayLiteral: maskedCorners)
    }
}

