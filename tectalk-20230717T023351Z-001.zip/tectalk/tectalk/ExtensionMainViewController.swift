//
//  ExtensionMainViewController.swift
//  tectalk
//
//  Created by min on 2021/11/03.
//

import Foundation
import UIKit
import CoreBluetooth



extension MainViewController: CBCentralManagerDelegate {
    
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
            
        case .unknown:
            print("central.state is unknown")
            systemBluetoothConnectedState = false
            connectError()
        case .resetting:
            print("central.state is resetting")
            systemBluetoothConnectedState = false
        case .unsupported:
            print("central.state is unsupported")
            systemBluetoothConnectedState = false
            connectError()
            
        case .unauthorized:
            print("central.state is unauthorized")
            systemBluetoothConnectedState = false
        case .poweredOff:
            print("central.state is poweredOff")
            systemBluetoothConnectedState = false
        case .poweredOn:
            print("central.state is poweredOn")
            central.scanForPeripherals(withServices: nil)
            systemBluetoothConnectedState = true
            
        @unknown default:
            print("central.state default case")
            systemBluetoothConnectedState = false
        }
        
        UIView.animate(withDuration: 0.5,delay:  0 ,options:  [.repeat] ) {
            let rotate = CGAffineTransform(rotationAngle: .pi)
            self.reFreshButton.transform = rotate
            
        } completion: {
            result in let rotate = CGAffineTransform(rotationAngle: .zero)
            self.reFreshButton.transform = rotate
            
        }
        
        
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        if !nearbyPeripherals.contains(where: {$0.0 == peripheral}), peripheral.name != nil{
            var macData = ""
            
            nearbyPeripherals.append((peripheral,macData))
            bleListTable.reloadData()
            
            
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        
        
        print("connected!")
        Swift.print("write withoutResponse length : \(peripheral.maximumWriteValueLength(for: .withoutResponse))")
        Swift.print("write withResponse length : \(peripheral.maximumWriteValueLength(for: .withResponse))")
        
        ConnectingButton.setTitle("연결중", for: .normal)
        ConnectingButton.titleLabel!.textAlignment = .center
        
        closebleViewButton.setTitle("", for: .normal)
        closebleViewButton.titleLabel!.textAlignment = .center
        
        deskTop1ImageView.isHidden = false
        deskTop2ImageView.isHidden = false
        deskMiddle1ImageView.isHidden = false
        deskMiddle2ImageView.isHidden = false
        deskBottomImageView.isHidden = false
        desksideLabel.isHidden = false
        
        unconnectTop1.isHidden = true
        unconnectTop2.isHidden = true
        unconnectmid1.isHidden = true
        unconnectmid2.isHidden = true
        unconnectedbottom.isHidden = true
        unconnectdesktitle.isHidden = true
        
        singledeskupperTopImageView.isHidden = false
        singledeskMiddleImageView.isHidden = false
        singledeskBottomImageView.isHidden = false
        singleconnectLabel.isHidden = false
        
        singleinacttop.isHidden = true
        singleinactmid.isHidden = true
        singleinactbottom.isHidden = true
        singleDeskSide.isHidden = true

        connectedPeripheral = peripheral
        // 아래 파라미터가 nil이면 모든 서비스를 검색.
        delegate?.didConnectedPeripheral?(peripheral)
//        stopScanPeripheral()
        peripheral.delegate = self
        peripheral.discoverServices(nil)
        
        reFreshButton.layer.removeAllAnimations()
 
    }
    
    public func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        
        deskTop1ImageView.isHidden = true
        deskTop2ImageView.isHidden = true
        deskMiddle1ImageView.isHidden = true
        deskMiddle2ImageView.isHidden = true
        deskBottomImageView.isHidden = true
        desksideLabel.isHidden = true
        
        unconnectTop1.isHidden = false
        unconnectTop2.isHidden = false
        unconnectmid1.isHidden = false
        unconnectmid2.isHidden = false
        unconnectedbottom.isHidden = false
        unconnectdesktitle.isHidden = false
        
        singledeskupperTopImageView.isHidden = true
        singledeskMiddleImageView.isHidden = true
        singledeskBottomImageView.isHidden = true
        singleconnectLabel.isHidden = true
        
        singleinacttop.isHidden = false
        singleinactmid.isHidden = false
        singleinactbottom.isHidden = false
        singleDeskSide.isHidden = false


        
    }
    
    public func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("BLEManager --> didDisconnectPeripheral")
        
        connectedPeripheral = nil
        //        timer.invalidate()
        ConnectingButton.setTitle("연결하기", for: .normal)
        ConnectingButton.titleLabel!.textAlignment = .center
        deskTop1ImageView.isHidden = true
        deskTop2ImageView.isHidden = true
        deskMiddle1ImageView.isHidden = true
        deskMiddle2ImageView.isHidden = true
        deskBottomImageView.isHidden = true
        desksideLabel.isHidden = true
        
        
        singledeskupperTopImageView.isHidden = true
        singledeskMiddleImageView.isHidden = true
        singledeskBottomImageView.isHidden = true
        singleconnectLabel.isHidden = true
        
        
        UIView.animate(withDuration: 0.5,delay:  0 ,options:  [.repeat] ) {
            let rotate = CGAffineTransform(rotationAngle: .pi)
            self.reFreshButton.transform = rotate
            
        } completion: {
            result in let rotate = CGAffineTransform(rotationAngle: .zero)
            self.reFreshButton.transform = rotate
            
        }
        
        
        self.delegate?.didDisconnectPeripheral?(peripheral)
        
    }
    
}

extension MainViewController: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        connectedPeripheral = peripheral
        
        guard let services = peripheral.services else {return}
        for service in services {
            print("service : \(service)")
            peripheral.discoverCharacteristics(nil, for: service)
            Swift.print(peripheral)
        }
        
    }
    
    
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let chars = service.characteristics else {
            return
        }
        
        guard chars.count > 0 else {
            return
        }
        
        for char in chars {
            print("char : \(char)")
            peripheral.setNotifyValue(true, for: char)
            peripheral.discoverDescriptors(for: char)
            
            if char.properties.contains(.write) {
                writeChar = char
            }
            
            if char.properties.contains(.read) {
                peripheral.readValue(for: char)
            }
            
        }
        
        delegate?.didDiscoverCharacteriticsFor?(peripheral, service)
        
    }

    public func peripheral(_ peripheral: CBPeripheral, didDiscoverDescriptorsFor characteristic: CBCharacteristic, error: Error?) {
        if error != nil {
     
            delegate?.didFailToDiscoverDescriptors?(error!)
            return
        }
        delegate?.didDiscoverDescriptors?(characteristic)
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if let value = characteristic.value {
            let bytes = [UInt8](value)
            
            dataByteString.append(contentsOf: bytes.hexa.uppercased())
            
            Swift.print(bytes)
            
           
            if dataByteString.contains("0D0A") {
                
                let deskheight = dataByteString.prefix(8)
                let deskinfinity = deskheight.prefix(4)
                let deskwork = deskheight.suffix(4)
                let decimal: Int = Int(deskinfinity, radix: 16)!
                let seconddecimal : Int = Int(deskwork, radix: 16)!
                Swift.print("묶어서 + \(deskheight)+\(deskinfinity) + \(deskwork) + \(decimal) + \(seconddecimal)")
                let deskinfi = Double(decimal)
                let deskinfis = String((deskinfi)/10)
                let deskinfiss = Int((deskinfi)/10)
                let deskworking = Double(seconddecimal)
                let deskworks = String((deskworking)/10)
                let deskworkss = Int((deskworking)/10)
                
                currdeskheights = Double(deskworks)!
                infideskheight = Double(deskinfis)!
                
                if (deskinfi>600&&deskinfi<1300) {
                    
                    if (preResultValue1 != deskinfi) {
                        if deskinfi < 1000 {
                            self.infinitySpaceValueLabel.text = String(deskinfis) + "cm"
                            self.singleinfinitySpaceValueLabel.text = String(deskinfis) + "cm"
                        }
                        else
                        {
                            self.infinitySpaceValueLabel.text = String(deskinfiss) + "cm"
                            self.singleinfinitySpaceValueLabel.text = String(deskinfiss) + "cm"
                            
                        }
                    }
                    
                    
                }
                
                if (deskworking>600&&deskworking<1300) {
                    if (preResultValue2 != deskworking) {
                        if deskworking < 1000 {
                            self.workSpaceValueLabel.text = String(deskworks) + "cm"
                            
                        }
                        else
                        {
                            self.workSpaceValueLabel.text = String(deskworkss) + "cm"
                            
                        }
                    }
                    else {

                    }
                    
                }
           
                print("data frame : \(dataByteString)")
                dataByteString = ""
                
//                moveDeskPostion(v1: (currdeskheights - MainViewController.SPACE_MIN) / 64, v2: (infideskheight - MainViewController.SPACE_MIN) / 64)
//                moveDeskPostions(v4: (infideskheight - MainViewController.SPACE_MIN) / 64)
            }
            
        }
        
    }
}

extension StringProtocol {
    var hexa: [UInt8] {
        var startIndex = self.startIndex
        return (0..<count/2).compactMap { _ in
            let endIndex = index(after: startIndex)
            defer { startIndex = index(after: endIndex) }
            return UInt8(self[startIndex...endIndex], radix: 16)
        }
    }
}
extension Sequence where Element == UInt8 {
    var data: Data { .init(self) }
    var hexa: String { map { .init(format: "%02x", $0) }.joined() }
}


extension MainViewController {
    
    func initViews(){
    
        singleinfinitySpaceUpBtn.roundCorners(cornerRadius: 16, maskedCorners: [.layerMinXMinYCorner, .layerMaxXMinYCorner])
        singleinfintySpaceDownBtn.roundCorners(cornerRadius: 16, maskedCorners: [.layerMinXMaxYCorner, .layerMaxXMaxYCorner])
        
        singleinfinitySpaceUpBtn.setTitle("", for: .normal)
        singleinfintySpaceDownBtn.setTitle("", for: .normal)
     
        singleinfinitySpaceUpBtn.setImage(UIImage(named: "up"), for: .normal)
        singleinfintySpaceDownBtn.setImage(UIImage(named: "down"), for: .normal)
     
//        
        let value = Double(floor(currnet_workSpace))
        
        let change = String(format: "%.1f", value)

        
        let value1 = change + "cm"
   self.singleinfinitySpaceValueLabel.text = value1

//     
    }
    

}


