//
//  FailConnectViewController.swift
//  tectalk
//
//  Created by min on 2021/10/25.
//


import Foundation
import UIKit


class FailConnectViewController: UIViewController {
    @IBOutlet weak var connectErrorView: UIView!
    @IBOutlet weak var errorMessageLabel: UILabel!
    @IBOutlet weak var errorContentLabel: UILabel!
    @IBOutlet weak var closeButton: UIButton!
    
    override func viewDidLoad() {
        connectErrorView.layer.cornerRadius = 15.0
        
    }
    @IBAction func dismissView(_ sender: Any) {
        
        self.dismiss(animated: true)
        
    }
}
